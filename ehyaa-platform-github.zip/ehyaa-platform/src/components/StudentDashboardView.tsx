import React, { useState } from 'react';
import { 
  TrendingUp, 
  BookOpen, 
  CheckCircle2, 
  Play, 
  KeyRound, 
  Clock, 
  BarChart3, 
  Calendar, 
  Flame, 
  Target, 
  ArrowUpRight, 
  GraduationCap,
  Sparkles,
  Award
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';
import { Lesson, StudentUser } from '../types';
import { MySubscriptionPanel } from './MySubscriptionPanel';
import { StudyPlannerPanel } from './StudyPlannerPanel';
import { MistakesPanel } from './MistakesPanel';
import * as api from '../services/api';
import { addDays, attendanceDays, cairoDay, courseSummary, fmtMinutes, formatCairo, lastDays, lessonStatus, streak as calcStreak, watchSecondsBetween } from '../utils/progress';

interface StudentDashboardViewProps {
  currentStudent: StudentUser | null;
  lessons: Lesson[];
  onSelectLesson: (id: string) => void;
  onOpenLoginModal: () => void;
  onSubscriptionChanged?: () => void;
}

export const StudentDashboardView: React.FC<StudentDashboardViewProps> = ({
  currentStudent,
  lessons,
  onSelectLesson,
  onOpenLoginModal,
  onSubscriptionChanged
}) => {
  // Chart tab: daily, weekly, monthly, quizzes
  const [metricTab, setMetricTab] = useState<'watch' | 'quizzes'>('watch');
  const [idCopied, setIdCopied] = useState(false);

  const studentName = currentStudent ? currentStudent.name : 'طالب الأحياء';
  const studentGrade = currentStudent?.grade || '3ث';
  
  // Filter lessons for student's grade
  const gradeLessons = lessons.filter(l => l.grade === studentGrade);
  const displayLessons = gradeLessons.length > 0 ? gradeLessons : lessons;

  // Every number below is computed from the student's real records (no fixed targets or fake rates)
  const published = displayLessons;
  const course = courseSummary(currentStudent, published);
  const days = attendanceDays(currentStudent);
  const streakDays = calcStreak(currentStudent);
  const today = cairoDay();
  const todaySec = watchSecondsBetween(currentStudent, today, today);
  const weekSec = watchSecondsBetween(currentStudent, addDays(today, -6), today);
  const monthSec = watchSecondsBetween(currentStudent, addDays(today, -29), today);
  const watchChartData = lastDays(currentStudent, 14);
  const hasWatchData = watchChartData.some(d => d.minutes > 0);
  const resumeId = currentStudent?.lastWatchedLessonId;
  const resumeLesson = resumeId ? lessons.find(l => l.id === resumeId) : undefined;
  const resumeState = resumeLesson ? lessonStatus(currentStudent, resumeLesson.id) : null;

  const quizScoresData = (currentStudent?.quizScores || []).map((qs) => ({
    name: qs.lessonTitle.length > 20 ? qs.lessonTitle.slice(0, 20) + '...' : qs.lessonTitle,
    scorePercent: Math.round((qs.score / qs.total) * 100),
    scoreRaw: `${qs.score}/${qs.total}`,
    date: qs.date
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in duration-300 space-y-8">
      
      {currentStudent && <MySubscriptionPanel code={currentStudent.codeUsed} onChanged={onSubscriptionChanged} />}

      {currentStudent && <StudyPlannerPanel code={currentStudent.codeUsed} lessons={lessons} />}

      {currentStudent && (
        <MistakesPanel
          student={currentStudent}
          onAddToPlanner={async (lesson) => {
            const tomorrow = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Africa/Cairo' }).format(new Date(Date.now() + 86400_000));
            const r = await api.studySaveItem(currentStudent.codeUsed, { title: `مراجعة: ${lesson}`.slice(0, 120), subject: 'أحياء', kind: 'study', repeat: 'once', days: [], onceDate: tomorrow, startTime: '18:00', endTime: '19:00', remindBeforeMin: 10, enabled: true });
            return r.ok;
          }}
        />
      )}

      {/* If student not logged in: Clean Alert */}
      {!currentStudent && (
        <div className="bg-gradient-to-r from-emerald-500/15 via-slate-800 to-slate-900 border border-emerald-500/40 rounded-3xl p-6 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-black shrink-0 shadow-lg">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display font-black text-lg text-white">
                لوحة متابعة نسب مشاهدة محاضرات الأحياء
              </h3>
              <p className="text-xs text-slate-300 mt-0.5">
                سجّل دخولك بكود الطالب المسلم لك من المدرس لتسجيل تقدمك الفعلي وحفظ نتائجك أولاً بأول.
              </p>
            </div>
          </div>

          <button
            onClick={onOpenLoginModal}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-emerald-500/20 transition whitespace-nowrap self-start sm:self-auto"
          >
            تسجيل الدخول بكود الطالب 🔑
          </button>
        </div>
      )}

      {/* Student Profile Header Card */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-500/40 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {currentStudent ? 'حساب مفعل رسمياً' : 'لوحة الطالب'}
              </span>
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-xs border border-emerald-500/40 flex items-center gap-1">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>{studentGrade === '1ث' ? 'الصف الأول الثانوي' : studentGrade === '2ث' ? 'الصف الثاني الثانوي' : 'الصف الثالث الثانوي'}</span>
              </span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-display font-black text-white">
              مرحباً يا بطل، {studentName} 👋
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
              منصة الدكتور محمد علي للأحياء — تابع تقدمك الحقيقي في المحاضرات وأيام دخولك ووقت مشاهدتك الفعلي.
            </p>
            {currentStudent && (
              <button
                type="button"
                onClick={() => { try { navigator.clipboard?.writeText(currentStudent.codeUsed); setIdCopied(true); setTimeout(() => setIdCopied(false), 1800); } catch { /* ignore */ } }}
                className="mt-3 inline-flex items-center gap-2.5 rounded-xl bg-slate-950/60 border border-emerald-500/40 px-3.5 py-2 hover:bg-slate-950/80 transition"
                title="اضغط لنسخ الـID"
              >
                <KeyRound className="w-4 h-4 text-emerald-400" />
                <span className="text-[11px] font-bold text-slate-400">ID الطالب</span>
                <span dir="ltr" className="font-mono font-black text-base tracking-wider text-emerald-300">{currentStudent.codeUsed}</span>
                <span className="text-[10px] font-bold text-slate-500">{idCopied ? 'تم النسخ ✓' : 'نسخ'}</span>
              </button>
            )}
          </div>

          {/* Quick Streak & Total Watch Box */}
          <div className="flex items-center gap-4 bg-slate-800/90 p-4 rounded-2xl border border-slate-700/80">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex flex-col items-center justify-center font-black">
              <Flame className="w-6 h-6 text-emerald-400 animate-bounce" />
              <span className="text-[10px] font-bold">{streakDays} يوم</span>
            </div>
            <div>
              <span className="text-xs text-slate-400 block font-medium">أيام دخول متتالية</span>
              <strong className="text-sm font-bold text-white block mt-0.5 font-mono">
                {fmtMinutes(monthSec)} مشاهدة آخر 30 يوماً
              </strong>
            </div>
          </div>
        </div>
      </div>

      {/* Resume where you stopped */}
      {currentStudent && resumeLesson && resumeState && resumeState.status !== 'done' && (
        <div className="bg-gradient-to-r from-emerald-500/15 via-slate-800 to-slate-900 border border-emerald-500/40 rounded-3xl p-5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[11px] text-emerald-300 font-bold">أكمل من حيث توقفت</span>
            <h3 className="font-display font-black text-base mt-0.5">{resumeLesson.title}</h3>
            <p className="text-xs text-slate-400 mt-0.5">أنجزت {resumeState.percent}% من هذه المحاضرة</p>
          </div>
          <button
            onClick={() => onSelectLesson(resumeLesson.id)}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1.5 self-start sm:self-auto"
          >
            <Play className="w-3.5 h-3.5 fill-current" /> متابعة المشاهدة
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="text-slate-400 font-bold text-xs flex items-center gap-1.5 mb-3">
            <Target className="w-4 h-4 text-purple-400" /> إكمال الكورس
          </div>
          <div className="text-3xl font-display font-black text-purple-400 font-mono">
            {course.percent === null ? '—' : `${course.percent}%`}
          </div>
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden border border-slate-700 my-3">
            <div style={{ width: `${course.percent ?? 0}%` }} className="h-full bg-gradient-to-l from-purple-400 to-purple-600" />
          </div>
          <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-800">
            {course.total === 0 ? 'لا توجد محاضرات منشورة بعد' : `${course.completed} من ${course.total} محاضرة مكتملة`}
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="text-slate-400 font-bold text-xs flex items-center gap-1.5 mb-3">
            <Calendar className="w-4 h-4 text-emerald-400" /> أيام الدخول الفعلية
          </div>
          <div className="text-3xl font-display font-black text-emerald-400 font-mono">{currentStudent ? days : '—'}</div>
          <div className="text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800">
            آخر دخول سابق: <span className="text-white">{formatCairo(currentStudent?.prevSeenAt)}</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="text-slate-400 font-bold text-xs flex items-center gap-1.5 mb-3">
            <Clock className="w-4 h-4 text-emerald-400" /> وقت المشاهدة الفعلي
          </div>
          <div className="text-3xl font-display font-black text-emerald-400 font-mono">{fmtMinutes(todaySec)}</div>
          <div className="text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800">اليوم · آخر 7 أيام: <span className="text-white">{fmtMinutes(weekSec)}</span></div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl">
          <div className="text-slate-400 font-bold text-xs flex items-center gap-1.5 mb-3">
            <TrendingUp className="w-4 h-4 text-sky-400" /> آخر 30 يوماً
          </div>
          <div className="text-3xl font-display font-black text-sky-400 font-mono">{fmtMinutes(monthSec)}</div>
          <div className="text-[11px] text-slate-400 mt-3 pt-2 border-t border-slate-800">
            يُحتسب وقت التشغيل الفعلي فقط، ولا يُحتسب القفز في الفيديو
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------------- */}
      {/* RECHARTS COMPONENT: Interactive Visual Analysis (Daily, Weekly, Monthly, Quizzes) */}
      {/* ------------------------------------------------------------------- */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl text-white space-y-6">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs mb-1">
              <BarChart3 className="w-4 h-4" />
              <span>تحليل نشاطك</span>
            </div>
            <h2 className="text-xl font-display font-black text-white">
              وقت مشاهدتك الفعلي ودرجات اختباراتك
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              كل رقم محسوب من سجلاتك الفعلية
            </p>
          </div>

          {/* 4 Switcher Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-800/90 p-1.5 rounded-2xl border border-slate-700/70 text-xs font-bold overflow-x-auto max-w-full">
            <button
              onClick={() => setMetricTab('watch')}
              className={`px-3 py-1.5 rounded-xl transition whitespace-nowrap ${
                metricTab === 'watch' ? 'bg-emerald-500 text-slate-950 font-black shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              وقت المشاهدة (14 يوماً) 📅
            </button>

            <button
              onClick={() => setMetricTab('quizzes')}
              className={`px-3 py-1.5 rounded-xl transition whitespace-nowrap ${
                metricTab === 'quizzes'
                  ? 'bg-emerald-500 text-slate-950 font-black shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              درجات الاختبارات 🎯
            </button>
          </div>
        </div>

        {metricTab === 'watch' && (
          hasWatchData ? (
            <div className="h-72 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={watchChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="label" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 12, fontSize: 12 }}
                    formatter={(v: any) => [`${v} دقيقة`, 'مشاهدة فعلية']}
                  />
                  <Bar dataKey="minutes" radius={[6, 6, 0, 0]} fill="#f59e0b" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="py-12 text-center text-sm text-slate-400">لا توجد بيانات مشاهدة بعد. ابدأ محاضرة وسيظهر وقت مشاهدتك هنا.</div>
          )
        )}

        {/* TAB 4: QUIZ SCORES */}
        {metricTab === 'quizzes' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between text-xs text-slate-400 px-2">
              <span>درجات الاختبارات الدورية لمقرر {studentGrade === '1ث' ? 'الصف الأول الثانوي' : studentGrade === '2ث' ? 'الصف الثاني الثانوي' : 'الصف الثالث الثانوي'}</span>
              <span className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-emerald-400 inline-block" />
                <span>الدرجة المحققة</span>
              </span>
            </div>

            <div className="h-72 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={quizScoresData}
                  margin={{ top: 10, right: 10, left: -20, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                  <XAxis 
                    dataKey="name" 
                    stroke="#94a3b8" 
                    fontSize={11} 
                    tickLine={false}
                  />
                  <YAxis 
                    stroke="#94a3b8" 
                    fontSize={11} 
                    domain={[0, 100]} 
                    tickFormatter={(val) => `${val}%`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#334155',
                      borderRadius: '16px',
                      color: '#f8fafc',
                      fontSize: '12px'
                    }}
                    formatter={(value: any, name: any, item: any) => [
                      `${value}% (${item.payload.scoreRaw})`, 
                      'الدرجة'
                    ]}
                    labelStyle={{ color: '#f59e0b', fontWeight: 'bold' }}
                  />
                  <Bar 
                    dataKey="scorePercent" 
                    radius={[8, 8, 0, 0]}
                    fill="#f59e0b"
                  >
                    {quizScoresData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.scorePercent >= 85 ? '#10b981' : entry.scorePercent >= 70 ? '#f59e0b' : '#ef4444'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

      </div>

      {/* ------------------------------------------------------------------- */}
      {/* SECTION: Recent Watch Progress & Recommended Grade Lectures         */}
      {/* ------------------------------------------------------------------- */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl text-white space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs mb-1">
              <BookOpen className="w-4 h-4" />
              <span>محاضرات مقرر {studentGrade === '1ث' ? 'الصف الأول الثانوي' : studentGrade === '2ث' ? 'الصف الثاني الثانوي' : 'الصف الثالث الثانوي'}</span>
            </div>
            <h3 className="text-xl font-display font-black">
              نسب استكمال المحاضرات المقررة لصفك
            </h3>
          </div>
          <span className="text-xs font-mono text-slate-400">
            {displayLessons.length} محاضرات متاحة
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {displayLessons.map((l, idx) => {
            const st = lessonStatus(currentStudent, l.id);
            const progress = st.percent;

            return (
              <div
                key={l.id}
                className="p-5 rounded-2xl bg-slate-800/60 border border-slate-700/70 hover:border-emerald-500/50 transition space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-[10px] px-2 py-0.5 rounded-md bg-slate-900 font-mono text-emerald-400 font-bold">
                      {l.grade} · {l.unit}
                    </span>
                    <h4 className="text-sm font-bold text-white mt-1 leading-snug">
                      {l.title}
                    </h4>
                  </div>
                  <span className="text-xs text-slate-400 font-mono shrink-0">
                    {l.duration}
                  </span>
                </div>

                {/* Individual Lecture Watch Bar */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>نسبة الإنجاز:</span>
                    <span className="font-mono font-bold text-emerald-400">{progress}%</span>
                  </div>
                  <div className="w-full h-2 bg-slate-900 rounded-full overflow-hidden p-0.5 border border-slate-700">
                    <div
                      style={{ width: `${progress}%` }}
                      className={`h-full rounded-full transition-all duration-500 ${
                        progress === 100 ? 'bg-emerald-400' : progress > 0 ? 'bg-emerald-500' : 'bg-slate-700'
                      }`}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 text-xs">
                  <span className="text-slate-400 flex items-center gap-1">
                    {progress === 100 ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> تم المشاهدة بالكامل
                      </span>
                    ) : progress > 0 ? (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> جاري الاستكمال
                      </span>
                    ) : (
                      <span className="text-slate-400 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" /> جاهزة للمشاهدة
                      </span>
                    )}
                  </span>

                  <button
                    onClick={() => onSelectLesson(l.id)}
                    className="px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center gap-1.5 transition"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>مشاهدة المحاضرة</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
